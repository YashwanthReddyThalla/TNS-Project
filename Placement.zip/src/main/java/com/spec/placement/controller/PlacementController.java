package com.spec.placement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import com.spec.placement.entity.Placement;
import com.spec.placement.service.PlacementService;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;


@RestController
public class PlacementController {
	
	@Autowired
	private PlacementService pser;
	
	@PostMapping("/addplacement")
	public Placement addStudentPlacement(@RequestBody Placement placement) {
		return pser.addPlacement(placement);
	}
	
	@GetMapping("/getplacement")
	public List<Placement> getStudentPlacements(){
		return pser.getAllPlacement();
	}
	
	@GetMapping("/getplacement/{sid}")
	public Placement getStudentPlacement(@PathVariable Long sid) {
		return pser.getPlacement(sid);
	}
	
	@PutMapping("/updateplacement")
	public Placement updateStudentPlacement(@RequestBody Placement placement) {
		return pser.updatePlacement(placement);
	}
}
