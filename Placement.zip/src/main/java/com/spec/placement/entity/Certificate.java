package com.spec.placement.entity;

public class Certificate {

}
