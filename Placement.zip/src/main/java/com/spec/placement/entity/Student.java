package com.spec.placement.entity;

public class Student {

}
