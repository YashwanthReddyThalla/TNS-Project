package com.spec.placement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.spec.placement.entity.Placement;

public interface PlacementRepo extends JpaRepository<Placement, Long>{

}
