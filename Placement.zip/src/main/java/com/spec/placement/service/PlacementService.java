package com.spec.placement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spec.placement.entity.Placement;
import com.spec.placement.repository.PlacementRepo;

@Service
public class PlacementService {
	
	@Autowired
	private PlacementRepo prepo;
	
	public Placement addPlacement(Placement placement) {
		return prepo.save(placement);
	}
	
	public Placement updatePlacement(Placement placement) {
		Long stuid = placement.getSid();
		
		Placement placed = prepo.findById(stuid).get();
		placed.setDate(placement.getDate());
		placed.setYear(placement.getYear());
		return prepo.save(placed);
	}
	
	public List<Placement> getAllPlacement(){
		return prepo.findAll();
	}
	
	public Placement getPlacement(Long sid) {
		Placement p = prepo.findById(sid).get();
		return p;
	}
}
